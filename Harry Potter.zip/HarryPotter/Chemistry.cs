﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HarryPotter
{
     class Chemistry : Subjects
    {
        // TODO-chemicals list
    }
}
