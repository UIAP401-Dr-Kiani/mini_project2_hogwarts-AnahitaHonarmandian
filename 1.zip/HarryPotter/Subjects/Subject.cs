﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static HarryPotter.Enums;

namespace HarryPotter
{
    public class Subject : IFileWorker<Subject>
    {

        public string Name { get; }
        public int Capacity { get; }
        public int NumberOfStudents { get; private set; }
        public uint SemesterPresentation { get; }
        public TimeSpan Time { get; set; }
        public string FileName { get => "Subject.txt"; }

        public Subject(string name, int capacity, uint semesterPresentation, uint minuteDuration)
        {
            Name = name;
            Capacity = capacity;
            NumberOfStudents = 0;
            SemesterPresentation = semesterPresentation;
            Time = TimeSpan.FromMinutes(minuteDuration);
        }

        public void IncreaseStudent()
        {
            NumberOfStudents++;
        }
        public bool CanSignUp()
        {
            return Capacity - NumberOfStudents > 0;
        }

        public List<Subject> GetFromFile()
        {
            var subject = new List<Subject>();
            var list_temp = FileWorker.Read(FileName);

            foreach (List<string> sub_info in list_temp)
            {
                string name = sub_info[0];
                int capacity = int.Parse(sub_info[1]);
                int numberOfStudents = int.Parse(sub_info[2]);
                var semesterPresentation = sub_info[3];
                var time = sub_info[4];

                subject.Add(new Subject(name, capacity, numberOfStudents, semesterPresentation, time));
            }
            return subject;
        }
        bool isEqual(Subject subject)
        {
            return subject.Name == this.Name && subject.Capacity == this.Capacity && subject.NumberOfStudents == this.NumberOfStudents &&
                subject.SemesterPresentation==this.SemesterPresentation && subject.Time==this.Time;
        }
        bool IsDuplicate()
        {
            foreach (var subject in GetFromFile())
            {
                if (isEqual(subject))
                    return true;
            }

            return false;
        }
        public void WriteToFile()
        {
            if (!IsDuplicate())
                FileWorker.Write(FileName, ReadyToWrite());
        }

        public string ReadyToWrite()
        {
            return $"{Name}|{Capacity}|{NumberOfStudents}|{SemesterPresentation}|{Time}";
        }





    }
}
