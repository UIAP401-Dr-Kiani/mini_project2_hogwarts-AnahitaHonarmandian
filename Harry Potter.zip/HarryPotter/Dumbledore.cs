﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HarryPotter
{
     class Dumbledore : AllowedPerson
    {
        
        public Dorms DormList { get ; }

        public Dumbledore(Dorms dormList)
        {
            DormList = dormList;
        }


    }
}
